public class Admin extends user{
    public Admin(String username, String email, String password, String city, String animal){
        super(username, email, password, city, animal, "admin");
    }
}
