public class Meal {
    String name;
    int calories;

    public Meal(String name, int calories) {
        this.name = name;
        this.calories = calories;
    }
}
